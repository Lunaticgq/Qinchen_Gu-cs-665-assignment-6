package EmailGenerationApp;

public enum CustomerType {
    BUSINESS, VIP, RETURNING, FREQUENT, NEW;

    @Override
    public String toString() {
        switch (this) {
            case BUSINESS:
                return "Business";
            case VIP:
                return "VIP";
            case RETURNING:
                return "Returning";
            case FREQUENT:
                return "Frequent";
            case NEW:
                return "New";
            default:
                throw new IllegalArgumentException();
        }
    }
}
