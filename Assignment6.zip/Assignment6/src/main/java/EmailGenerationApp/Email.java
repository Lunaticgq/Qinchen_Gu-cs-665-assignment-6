/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: EmailTemplate.java
 */

package EmailGenerationApp;

public class Email {
//    private String template = "Dear [CUSTOMER_TYPE],\n\n[MESSAGE]\n\nRegards,\nThe Company";



    public String generateEmail(CustomerType type){
        EmailTemplateConfig config = new EmailTemplateConfig();
        switch (type){
            case BUSINESS:
                String template = config.getTemplate("BUSINESS_TEMPLATE");
                String customerType = config.getTemplate("BUSINESS_CUSTOMER_TYPE");
                String message = config.getTemplate("BUSINESS_MESSAGE");
                return template.replace("[CUSTOMER_TYPE]", customerType + " ")
                        .replace("[MESSAGE]", message);
            case RETURNING:
                String template1 = config.getTemplate("RETURNING_TEMPLATE");
                String customerType1 = config.getTemplate("RETURNING_CUSTOMER_TYPE");
                String message1 = config.getTemplate("RETURNING_MESSAGE");
                return template1.replace("[CUSTOMER_TYPE]", customerType1 + " ")
                        .replace("[MESSAGE]", message1);
            case FREQUENT:
                String template2 = config.getTemplate("FREQUENT_TEMPLATE");
                String customerType2 = config.getTemplate("FREQUENT_CUSTOMER_TYPE");
                String message2 = config.getTemplate("FREQUENT_MESSAGE");
                return template2.replace("[CUSTOMER_TYPE]", customerType2 + " ")
                        .replace("[MESSAGE]", message2);
            case NEW:
                String template3 = config.getTemplate("NEW_TEMPLATE");
                String customerType3 = config.getTemplate("NEW_CUSTOMER_TYPE");
                String message3 = config.getTemplate("NEW_MESSAGE");
                return template3.replace("[CUSTOMER_TYPE]", customerType3 + " ")
                        .replace("[MESSAGE]", message3);
            case VIP:
                String template4 = config.getTemplate("VIP_TEMPLATE");
                String customerType4 = config.getTemplate("VIP_CUSTOMER_TYPE");
                String message4 = config.getTemplate("VIP_MESSAGE");
                return template4.replace("[CUSTOMER_TYPE]", customerType4 + " ")
                        .replace("[MESSAGE]", message4);
            default:
                return "Invalid Customer Type";
        }

    }
}
