package EmailGenerationApp;

public class BusinessCustomer extends Customer {
    public BusinessCustomer(String name) {
        super(name, EmailFactory.getEmail(CustomerType.BUSINESS));
    }

    @Override
    public String generateEmail() {
        return email.replace("[NAME]", name);
    }
}
