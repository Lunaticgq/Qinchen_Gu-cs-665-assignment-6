package EmailGenerationApp;

public class EmailFactory {

    public static String getEmail(CustomerType type) {

        return new Email().generateEmail(type);
    }
}


