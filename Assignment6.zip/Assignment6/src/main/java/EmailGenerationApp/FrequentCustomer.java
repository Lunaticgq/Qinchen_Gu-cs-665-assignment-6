package EmailGenerationApp;

public class FrequentCustomer extends Customer {
    public FrequentCustomer(String name) {
        super(name, EmailFactory.getEmail(CustomerType.FREQUENT));
    }

    @Override
    public String generateEmail() {
        return email.replace("[NAME]", name);
    }
}
