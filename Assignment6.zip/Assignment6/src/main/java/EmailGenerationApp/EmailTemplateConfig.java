package EmailGenerationApp;

import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;

public class EmailTemplateConfig {
    private Properties templates;

    public EmailTemplateConfig() {
        templates = new Properties();
        loadTemplates();
    }

    private void loadTemplates() {
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("emailTemplates.properties")) {
            if (input == null) {
                throw new IOException("Unable to find emailTemplates.properties");
            }
            templates.load(input);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public String getTemplate(String key) {
        return templates.getProperty(key);
    }
}
