/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: EmailGenerationApp.java
 */

package EmailGenerationApp;

public class EmailGenerationApp {
    public static void main(String[] args) {
        Email email = new Email();

        Customer businessCustomer = new BusinessCustomer("Allen");
        System.out.println(businessCustomer.generateEmail());

        Customer returningCustomer = new ReturningCustomer("Daniel");
        System.out.println(returningCustomer.generateEmail());
//
//        Customer frequentCustomer = new FrequentCustomer("Justin", emailTemplate);
//        System.out.println(frequentCustomer.generateEmail());
//
//        Customer newCustomer = new NewCustomer("Qinchen", emailTemplate);
//        System.out.println(newCustomer.generateEmail());
//
//        Customer vipCustomer = new VIPCustomer("Gu", emailTemplate);
//        System.out.println(vipCustomer.generateEmail());
    }
}

