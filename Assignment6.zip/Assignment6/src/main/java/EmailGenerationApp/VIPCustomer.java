/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: VIPCustomer.java
 */

package EmailGenerationApp;

public class VIPCustomer extends Customer {
    public VIPCustomer(String name) {
        super(name, EmailFactory.getEmail(CustomerType.VIP));
    }

    @Override
    public String generateEmail() {
        return email.replace("[NAME]", name);
    }
}

