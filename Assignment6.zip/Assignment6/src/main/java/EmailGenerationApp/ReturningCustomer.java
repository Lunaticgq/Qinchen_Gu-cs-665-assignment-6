/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: ReturningCustomer.java
 */

package EmailGenerationApp;

public class ReturningCustomer extends Customer {
    public ReturningCustomer(String name) {
        super(name, EmailFactory.getEmail(CustomerType.RETURNING));
    }

    @Override
    public String generateEmail() {
        return email.replace("[NAME]", name);
    }
}

