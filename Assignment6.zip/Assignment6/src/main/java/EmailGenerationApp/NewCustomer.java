package EmailGenerationApp;

public class NewCustomer extends Customer {
    public NewCustomer(String name) {
        super(name, EmailFactory.getEmail(CustomerType.NEW));
    }

    @Override
    public String generateEmail() {
        return email.replace("[NAME]", name);
    }
}
