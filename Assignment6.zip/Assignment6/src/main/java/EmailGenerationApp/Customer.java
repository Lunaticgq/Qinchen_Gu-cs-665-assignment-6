/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: Customer.java
 */

package EmailGenerationApp;

public abstract class Customer {
    protected String name;
    protected String  email;

    public Customer(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public abstract String generateEmail();
}
