package edu.bu.met.cs665;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertTrue;
import EmailGenerationApp.BusinessCustomer;
import EmailGenerationApp.Customer;
import EmailGenerationApp.Email;
import EmailGenerationApp.FrequentCustomer;
import EmailGenerationApp.NewCustomer;
import EmailGenerationApp.ReturningCustomer;
import EmailGenerationApp.VIPCustomer;
import EmailGenerationApp.EmailFactory;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class EmailGenerationAppTest {

    @Before
    public void setUp() {
        EmailFactory templateFactory = new EmailFactory();
    }

    @Test
    public void testBusinessCustomerEmail() {
        Customer businessCustomer = new BusinessCustomer("Allen");
        String emailContent = businessCustomer.generateEmail();
        assertTrue(emailContent.contains("Business Customer Allen"));
        assertTrue(emailContent.contains("Thank you for your business! Here's a coupon for your next purchase!"));
    }

    @Test
    public void testReturningCustomerEmail() {
        Customer returningCustomer = new ReturningCustomer("Daniel");
        String emailContent = returningCustomer.generateEmail();
        assertTrue(emailContent.contains("Returns Customer Daniel"));
        assertTrue(emailContent.contains("It's been a while! Here's a coupon for your next purchase."));
    }

    @Test
    public void testFrequentCustomerEmail() {
        Customer frequentCustomer = new FrequentCustomer("Justin");
        String emailContent = frequentCustomer.generateEmail();
        assertTrue(emailContent.contains("Frequent Customer Justin"));
        assertTrue(emailContent.contains("Forget something? Here's a coupon for your next purchase."));
    }

    @Test
    public void testNewCustomerEmail() {
        Customer newCustomer = new NewCustomer("Qinchen");
        String emailContent = newCustomer.generateEmail();
        assertTrue(emailContent.contains("New Customer Qinchen"));
        assertTrue(emailContent.contains("Welcome to our store! Here's a coupon for your first purchase."));
    }

    @Test
    public void testVIPCustomerEmail() {
        Customer vipCustomer = new VIPCustomer("Gu");
        String emailContent = vipCustomer.generateEmail();
        assertTrue(emailContent.contains("VIP Customer Gu"));
        assertTrue(emailContent.contains("Thank you for being a VIP customer! Here's a coupon for your next purchase."));
    }
}
